### ViNT (Visual Navigation Transformer)

Files 
- `vint.py` : Main model file 
- `self_attention.py` : Positional encoding/decoder classes w/ self-attention for ViNT
