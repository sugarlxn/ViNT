### NoMaD (Navigation with Goal Masked Diffusion)

Files 
- `nomad.py` : Main model file 
- `nomad_vint.py` : Implementation of ViNT class for NoMaD
