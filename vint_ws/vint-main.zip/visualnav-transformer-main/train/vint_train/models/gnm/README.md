### GNM (General Navigation Model)

Files 
- `gnm.py` : Main model file 
- `modified_mobilenetv2.py` : Encoder file for GNM
